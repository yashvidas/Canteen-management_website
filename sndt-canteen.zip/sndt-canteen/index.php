<?php include('partials-front/menu.php'); ?>

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">

            <form action="Foodsearchdosa.html">
                <input type="search" name="search" placeholder="Search for Food..">
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
                
            </form>
        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->

    <!-- CAtegories Section Starts Here -->
    <section class="categories">
        <div class="container">
            <h2 class="text-center">Explore Foods</h2>
            
            <?php 
            //Create SQL Query to display categories from Database
            $sql = "SELECT * FROM tbl_category";
            //execute
            $res= mysqli_query($conn, $sql);
            //count the rows
            $count=mysqli_num_rows($res);

            if($count>0) 
            { 
                /*category available*/ 
                while($row=mysqli_fetch_assoc($res))
                {
                    $id = $row['id']; 
                    $title=$row['title'];
                    $image_name=$row['image_name'];
                    ?>
                    <a href="categoryCH.html">
                    <div class="box-3 float-container">
                        <?php
                        //check if img is available or not
                        if($image_name="")
                        {
                            echo "<div class='error'>Image Not Available</div>";
                        }
                        else
                        {
                            //img available
                            ?> 
                            <img src="<?php echo SITEURL; ?>images/<?php echo $image_name; ?>" alt="Chinese" class="img-responsive img-curve"> 
                            <?php 
                        }
                        
                        ?>
                        <h3 class="float-text text-white">Chinese</h3>
                     </div>
                    </a>

                    
                
            }
            
            {
                echo "<div class='error'>Category Not Added</div>";
            }
            
            ?>
            <a href="categorySOI.html">
            <div class="box-3 float-container">
                <img src="images/dosa1 menu.jpg" alt="South Indian" class="img-responsive img-curve">

                <h3 class="float-text text-white">South Indian</h3>
            </div>
            </a>

            

            
            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->

    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Plain-Dosa.jpg" alt="Plain Dosa" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Plain Dosa</h4>
                    <p class="food-price">Rs 30</p>
                    
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/masala-dosa.jpg" alt="Masala Dosa" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Masala Dosa</h4>
                    <p class="food-price">Rs 45</p>
                    
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/cheese dosa.jpg" alt="Cheese Dosa" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Cheese Dosa</h4>
                    <p class="food-price">Rs 40</p>
        
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/mix uttapam.jpg" alt="Mix Uttapam" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Mix Uttapam</h4>
                    <p class="food-price">Rs 40</p>
                
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/chole bhature.jpg" alt="Chole Bhature" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Chole Bhature</h4>
                    <p class="food-price">Rs 45</p>
                    
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Rajma-Chawal.jpg" alt="Rajma-Chawal" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Rajma Chawal</h4>
                    <p class="food-price">Rs 40</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>


            <div class="clearfix"></div>



        </div>

        <p class="text-center">
            <a href="Food.html">See All Foods</a>
        </p>
    </section>
    <!-- fOOD Menu Section Ends Here -->

   <?php include('partials-front/footer.php'); ?>  