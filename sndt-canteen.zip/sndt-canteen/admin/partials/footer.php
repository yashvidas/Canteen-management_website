<!-- Footer Section Starts -->
<div class="footer">
            <div class="wrapper">
                <p class="text-center">2020 All rights reserved, SNDT Canteen. Developed By MYN. </p>
        </div>
        <!-- Footer Section Ends -->

    </body>
</html>