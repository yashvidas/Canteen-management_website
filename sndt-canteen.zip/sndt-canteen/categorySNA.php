<?php include('partials-front/menu.php'); ?>

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <h2>Foods on <a href="#" class="text-white">"Snacks"</a></h2>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->



    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/samosa_pav.jpg" alt="samosa-pav" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Samosa Pav</h4>
                    <p class="food-price">Rs 15</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Vada pav.jpg" alt="Vada pav" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Vada Pav</h4>
                    <p class="food-price">Rs 15</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Chaat.jpg" alt="Chaat" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Chaat</h4>
                    <p class="food-price">Rs 25</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>
 


            <div class="clearfix"></div>

            

        </div>

    </section>
    <!-- fOOD Menu Section Ends Here -->

    <?php include('partials-front/footer.php'); ?> 