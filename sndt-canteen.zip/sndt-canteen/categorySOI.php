<?php include('partials-front/menu.php'); ?>

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <h2>Foods on <a href="#" class="text-white">"South Indian"</a></h2>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->



    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Plain-Dosa.jpg" alt="Plain Dosa" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Plain Dosa</h4>
                    <p class="food-price">Rs 30</p>
                    
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/masala-dosa.jpg" alt="Masala Dosa" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Masala Dosa</h4>
                    <p class="food-price">Rs 45</p>
                    
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/cheese dosa.jpg" alt="Cheese Dosa" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Cheese Dosa</h4>
                    <p class="food-price">Rs 40</p>
        
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/mix uttapam.jpg" alt="Mix Uttapam" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Mix Uttapam</h4>
                    <p class="food-price">Rs 40</p>
                
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>


            <div class="clearfix"></div>

            

        </div>

    </section>
    <!-- fOOD Menu Section Ends Here -->

    <?php include('partials-front/footer.php'); ?> 