<?php include('partials-front/menu.php'); ?>

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <form action="Foodsearchdosa.html" method="POST">
                <input type="search" name="search" placeholder="Search for Food.." required>
                <input type="submit" name="submit" value="Search" class="btn btn-primary">
            </form>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->



    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Plain-Dosa.jpg" alt="Plain Dosa" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Plain Dosa</h4>
                    <p class="food-price">Rs 30</p>
                    
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/masala-dosa.jpg" alt="Masala Dosa" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Masala Dosa</h4>
                    <p class="food-price">Rs 45</p>
                    
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/cheese dosa.jpg" alt="Cheese Dosa" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Cheese Dosa</h4>
                    <p class="food-price">Rs 40</p>
        
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/mix uttapam.jpg" alt="Mix Uttapam" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Mix Uttapam</h4>
                    <p class="food-price">Rs 40</p>
                
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>
            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/chole bhature.jpg" alt="Chole Bhature" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Chole Bhature</h4>
                    <p class="food-price">Rs 45</p>
                    
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Rajma-Chawal.jpg" alt="Rajma-Chawal" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Rajma Chawal</h4>
                    <p class="food-price">Rs 40</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Rice&Dal Makhani.JPG" alt="Rice&dal Makhani" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Rice & Dal Makhani</h4>
                    <p class="food-price">Rs 80</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Rice&paneer-butter-masala.jpg" alt="Rice&Paneer butter masala" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Rice & paneer Butter Masala</h4>
                    <p class="food-price">Rs 90</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Roti.jpg" alt="Roti" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Roti</h4>
                    <p class="food-price">Rs 10</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/veg noodles.png" alt="Veg Noodles" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Veg Noodles</h4>
                    <p class="food-price">Rs 45</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>


 <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/veg hakka noodles.jpg" alt="Veg hakka noodles" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Veg Hakka Noodles</h4>
                    <p class="food-price">Rs 40</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/veg fried-rice.jpg" alt="Veg fried rice" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Veg Fried Rice</h4>
                    <p class="food-price">Rs 45</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/veg momos.png" alt="momos" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Veg Momos</h4>
                    <p class="food-price">Rs 25</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>



            
            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/samosa_pav.jpg" alt="samosa-pav" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Samosa Pav</h4>
                    <p class="food-price">Rs 15</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Vada pav.jpg" alt="Vada pav" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Vada Pav</h4>
                    <p class="food-price">Rs 15</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Chaat.jpg" alt="Chaat" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Chaat</h4>
                    <p class="food-price">Rs 25</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>


            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Frooti.jpg" alt="Frooti" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Frooti</h4>
                    <p class="food-price">Rs 20</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Coca-Cola.jpg" alt="Coca Cola" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Coca Cola</h4>
                    <p class="food-price">Rs 15</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Watermelon-Juice.jpg" alt="Watermelon-Juice" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Watermelon Juice</h4>
                    <p class="food-price">Rs 30</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Masala-Chaas.jpg" alt="Masala Chaas" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Masala Chaas</h4>
                    <p class="food-price">Rs 25</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>






            <div class="clearfix"></div>

            

        </div>

    </section>
    <!-- fOOD Menu Section Ends Here -->

    <?php include('partials-front/footer.php'); ?> 