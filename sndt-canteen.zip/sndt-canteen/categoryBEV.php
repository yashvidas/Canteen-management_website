<?php include('partials-front/menu.php'); ?>

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <h2>Foods on <a href="#" class="text-white">"Beverages"</a></h2>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->



    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Frooti.jpg" alt="Frooti" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Frooti</h4>
                    <p class="food-price">Rs 20</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Coca-Cola.jpg" alt="Coca Cola" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Coca Cola</h4>
                    <p class="food-price">Rs 15</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Watermelon-Juice.jpg" alt="Watermelon-Juice" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Watermelon Juice</h4>
                    <p class="food-price">Rs 30</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Masala-Chaas.jpg" alt="Masala Chaas" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Masala Chaas</h4>
                    <p class="food-price">Rs 25</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

 


            <div class="clearfix"></div>

            

        </div>

    </section>
    <!-- fOOD Menu Section Ends Here -->

    <?php include('partials-front/footer.php'); ?> 