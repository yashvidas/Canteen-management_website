<?php include('partials-front/menu.php'); ?>

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <h2>Foods on <a href="#" class="text-white">"Chinese"</a></h2>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->



    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/veg noodles.png" alt="Veg Noodles" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Veg Noodles</h4>
                    <p class="food-price">Rs 45</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>


 <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/veg hakka noodles.jpg" alt="Veg hakka noodles" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Veg Hakka Noodles</h4>
                    <p class="food-price">Rs 40</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/veg fried-rice.jpg" alt="Veg fried rice" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Veg Fried Rice</h4>
                    <p class="food-price">Rs 45</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/veg momos.png" alt="momos" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Veg Momos</h4>
                    <p class="food-price">Rs 25</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>


            <div class="clearfix"></div>

            

        </div>

    </section>
    <!-- fOOD Menu Section Ends Here -->

    <?php include('partials-front/footer.php'); ?> 