<?php include('partials-front/menu.php'); ?>



    <!-- CAtegories Section Starts Here -->
    <section class="categories">
        <div class="container">
            <h2 class="text-center">Explore Foods</h2>

            <a href="categorySOI.html">
            <div class="box-3 float-container">
                <img src="images/dosa1 menu.jpg" alt="South Indian" class="img-responsive img-curve">

                <h3 class="float-text text-white">South Indian</h3>
            </div>
            </a>

            <a href="categoryCH.html">
            <div class="box-3 float-container">
                <img src="images/Noodles menu.jpg" alt="Chinese" class="img-responsive img-curve">

                <h3 class="float-text text-white">Chinese</h3>
            </div>
            </a>

            <a href="categoryNI.html">
            <div class="box-3 float-container">
                <img src="images/Bhatura menu.jpg" alt="North Indian" class="img-responsive img-curve">

                <h3 class="float-text text-white">North Indian</h3>
            </div>
            </a>

            <a href="categorySNA.html">
            <div class="box-3 float-container">
                <img src="images/samosa-pav menu.png" alt="Snacks" class="img-responsive img-curve">

                <h3 class="float-text text-white">Snacks</h3>
            </div>
            </a>

            <a href="categoryBEV.html">
            <div class="box-3 float-container">
                <img src="images/Masala-Chaas menu.jpg" alt="Beverages" class="img-responsive img-curve">

                <h3 class="float-text text-white">Beverages</h3>
            </div>
            </a>

            

            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->


    <?php include('partials-front/footer.php'); ?> 