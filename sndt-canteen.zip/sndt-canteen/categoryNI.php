<?php include('partials-front/menu.php'); ?>

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <h2>Foods on <a href="#" class="text-white">"North Indian"</a></h2>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->



    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/chole bhature.jpg" alt="Chole Bhature" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Chole Bhature</h4>
                    <p class="food-price">Rs 45</p>
                    
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Rajma-Chawal.jpg" alt="Rajma-Chawal" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Rajma Chawal</h4>
                    <p class="food-price">Rs 40</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Rice&Dal Makhani.JPG" alt="Rice&dal Makhani" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Rice & Dal Makhani</h4>
                    <p class="food-price">Rs 80</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Rice&paneer-butter-masala.jpg" alt="Rice&Paneer butter masala" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Rice & paneer Butter Masala</h4>
                    <p class="food-price">Rs 90</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="food-menu-box">
                <div class="food-menu-img">
                    <img src="images/Roti.jpg" alt="Roti" class="img-responsive img-curve">
                </div>

                <div class="food-menu-desc">
                    <h4>Roti</h4>
                    <p class="food-price">Rs 10</p>
                   
                    </p>
                    <br>

                    <a href="order.html" class="btn btn-primary">Order Now</a>
                </div>
            </div>

            <div class="clearfix"></div>

            

        </div>

    </section>
    <!-- fOOD Menu Section Ends Here -->

    <?php include('partials-front/footer.php'); ?> 